# -*- coding: utf-8 -*-
#    Copyright (C) 2017 Sebastian Golasch (plugin.video.netflix)

#    SPDX-License-Identifier: MIT
#    See LICENSES/MIT.md for more information.
