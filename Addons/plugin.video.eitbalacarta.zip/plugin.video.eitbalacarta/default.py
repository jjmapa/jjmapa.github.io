# coding: utf-8
import sys
import xbmcgui
import xbmcplugin
import xbmc
import urllib
import urllib2
import urlparse
import json
import xbmcaddon
import os
import re
import unicodedata
from lib import youtube_dl
 
base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])
my_addon = xbmcaddon.Addon()
PATH = my_addon.getAddonInfo('path')

sys.path.append(xbmc.translatePath(os.path.join(PATH, 'lib')))
 
def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

def download_video_url(page_url, local_path, title):
    ydl = youtube_dl.YoutubeDL({'outtmpl': local_path})
    result = ydl.extract_info(page_url, download=False)
    a = json.dumps(result).split('.mp4"')
    b = a[-2].split('"')
    request_video = urllib2.Request(b[-1] + '.mp4')

    response = urllib2.urlopen(request_video)
    CHUNK = 16 * 1024
    with open(local_path, 'wb') as f:
        while True:
            chunk = response.read(CHUNK)
            if not chunk:
                break
            f.write(chunk)
    f.close()
    xbmc.executebuiltin('XBMC.Notification(%s, %s, %s, %s)' % ('Descarga Finalizada', title, 4000, PATH + '/icon.png'))

def get_video_url(page_url):
    video_urls = []
    ydl = youtube_dl.YoutubeDL({'outtmpl': u'%(id)s%(ext)s'})
    result = ydl.extract_info(page_url, download=False)
    if 'entries' in result:
        video = result['entries'][0]
    else:
        video = result
    return video

def string_friendly(string_in):
    string_out = string_in.lower()
    string_out = string_out.replace(' ', '-')
    string_out = string_out.replace('á', 'a')
    string_out = string_out.replace('é', 'e')
    string_out = string_out.replace('í', 'i')
    string_out = string_out.replace('ó', 'o')
    string_out = string_out.replace('ú', 'u')
    string_out = string_out.replace('(', '')
    string_out = string_out.replace(')', '')
    return string_out

def strip_accents(text):
    try:
        text = unicode(text.encode("utf-8"), 'utf-8')
    except NameError:
        pass
    text = unicodedata.normalize('NFD', text)\
           .encode('ascii', 'ignore')\
           .decode("utf-8")
    return str(text)

def only_legal_chars(string_in):
    string_out = strip_accents(string_in)
    string_out = re.sub(r'[\\/:"*?<>|]+', "", string_out)
    string_out = "".join(i for i in string_out if ord(i)<128)
    string_out = ' '.join(string_out.split())
    return string_out

mode = args.get('mode', None)

if mode is None:

    request = urllib2.Request('https://www.eitb.tv/es/menu/getMenu/tv/')
    home_data = urllib2.urlopen(request).read()

    a = home_data.split('hash="')
    b = a[2].split('"')

    request = urllib2.Request('https://www.eitb.tv/es/menu/getMenu/tv/' + b[0] + '/')
    index_data = urllib2.urlopen(request).read()

    a = index_data.split('<node>')

    for x in range(1, len(a)):
        b = a[x].split('<title>')
        c = b[1].split('</title>')

        c[0] = c[0].replace('&amp;', '&')

        d = a[x].split('hash="')
        e = d[1].split('"')

        url = build_url({'mode': 'indice', 'title': c[0], 'hash': e[0]})
        li = xbmcgui.ListItem(c[0], iconImage = PATH + '/icon.png')
        li.setInfo(type="Video", infoLabels={"plot": c[0]})
        li.setArt({'fanart': PATH + '/fanart.jpg'})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] == 'indice':

    request = urllib2.Request('https://www.eitb.tv/es/menu/getMenu/tv/' + args['hash'][0] + '/')
    show_data = urllib2.urlopen(request).read()

    a = show_data.split('<node>')

    for x in range(1, len(a)):
        b = a[x].split('<title>')
        c = b[1].split('</title>')

        c[0] = c[0].replace('&amp;', '&')

        d = a[x].split('<id>')
        if len(d) > 1:
            e = d[1].split('</id>')
            f = a[x].split('<id_web_group>')
            g = f[1].split('</id_web_group>')
            url = build_url({'mode': 'show', 'title': c[0], 'id': e[0], 'id_web_group': g[0]})
        else:
            d = a[x].split('<submenu hash="')
            e = d[1].split('"')
            url = build_url({'mode': 'indice', 'title': c[0], 'hash': e[0]})
        
        li = xbmcgui.ListItem(c[0], iconImage = PATH + '/icon.png')
        li.setInfo(type="Video", infoLabels={"plot": c[0]})
        li.setArt({'fanart': PATH + '/fanart.jpg'})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] == 'show':

    request = urllib2.Request('https://mam.eitb.eus/mam/REST/ServiceMultiweb/Playlist/MULTIWEBTV/' + args['id'][0] + '/')
    json_show = json.loads(urllib2.urlopen(request).read())

    for item in json_show['web_media']:

        item['NAME_ES'] = item['NAME_ES'].replace('&amp;', '&')

        commands = []

        cmd = 'XBMC.RunPlugin({})'.format(build_url({'mode': 'download', 'show_title': args['title'][0], 'show_id': args['id'][0], 'title': item['NAME_ES'], 'id': item['ID_WEB_MEDIA'], 'file_title': args['title'][0] + ' - ' + item['NAME_ES']}))
        commands.append(( 'Descargar', cmd ))

        url = build_url({'mode': 'episode', 'show_title': args['title'][0], 'show_id': args['id'][0], 'title': item['NAME_ES'], 'id': item['ID_WEB_MEDIA']})
        li = xbmcgui.ListItem('[' + item['IDIOMA'] + '] ' + item['NAME_ES'], iconImage = item['STILL_URL'])
        li.setInfo(type="Video", infoLabels = {
            "plot": "[B]" + args['title'][0] + "\n\n[/B][" + item['IDIOMA'] + '] ' + item['NAME_ES'] + "\n\n" + item['SHORT_DESC_ES'], 
            "Title" : item['NAME_ES'], 
            "Duration" : item['LENGTH']/1000
        })
        li.setArt({'fanart': item['STILL_URL']})
        li.addContextMenuItems(commands)
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0] == 'episode':
    videos = get_video_url('https://www.eitb.tv/es/video/' + string_friendly(args['show_title'][0]) + '/' + args['show_id'][0] + '/' + args['id'][0] + '/' + string_friendly(args['title'][0]) + '/')
    listitem = xbmcgui.ListItem(args['title'][0])
    listitem.setInfo('video', {'Title': args['title'][0]})
    if 'manifest_url' in videos:
        xbmc.Player().play(videos['manifest_url'], listitem)
    else:
        xbmc.Player().play(videos['url'], listitem)

elif mode[0] == 'download':
    dialog = xbmcgui.Dialog().browse(0, 'Elige un directorio para descargar el video', "video")
    if dialog != '':
        download_video_url('https://www.eitb.tv/es/video/' + string_friendly(args['show_title'][0]) + '/' + args['show_id'][0] + '/' + args['id'][0] + '/' + string_friendly(args['title'][0]) + '/', dialog + only_legal_chars(args['file_title'][0]) + '.mp4', args['title'][0])