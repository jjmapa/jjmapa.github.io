# -*- coding: utf-8 -*-

import xbmc
xbmc.executebuiltin('RunPlugin(plugin://plugin.video.music/?action=service)')
