script.module.cfscraper
======================

Python cfscraper library packed for Kodi.

See https://github.com/Anorov/cloudflare-scrape

For instructions on how to clone the repo see the contributing.md file
